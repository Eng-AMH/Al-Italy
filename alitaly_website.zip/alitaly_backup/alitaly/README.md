# Al-Italy Patisserie — Luxury Digital Menu Platform

A production-ready, mobile-first luxury dessert catalog accessed via QR code.  
Built with Python Flask · SQLAlchemy · SQLite → PostgreSQL · Gold × Black design system.

---

## Quick Start (Local)

```bash
# 1. Clone / extract project
cd alitaly

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Copy environment file
cp .env.example .env
# Edit .env and set your SECRET_KEY

# 5. Run the app (auto-creates DB tables)
python run.py

# 6. Seed luxury data (in a second terminal)
python seed/seed_data.py
```

Visit: **http://localhost:5000/**  
Admin:  **http://localhost:5000/admin**  
Login:  `admin` / `alitaly2024!`

---

## Project Structure

```
alitaly/
├── app/
│   ├── __init__.py         # App factory (Flask + SQLAlchemy + Login)
│   ├── models/
│   │   └── __init__.py     # All DB models
│   ├── routes/
│   │   ├── public.py       # Customer-facing routes + item API
│   │   ├── admin.py        # Full admin panel routes
│   │   └── api.py          # REST endpoints for filtering/search
│   ├── services/           # Business logic layer (extendable)
│   └── utils/              # Helper utilities
├── config/
│   └── settings.py         # Dev / Production config
├── templates/
│   ├── public/
│   │   └── index.html      # Single unified luxury catalog page
│   └── admin/
│       ├── layout.html     # Admin base layout
│       ├── login.html      # Secure login page
│       ├── dashboard.html  # Stats + activity overview
│       ├── items.html      # Item management list
│       ├── item_form.html  # Add / edit item (full fields)
│       ├── categories.html # Category management
│       ├── category_form.html
│       ├── reviews.html    # Review moderation panel
│       ├── brand.html      # Brand settings + logo upload
│       └── qr.html         # QR code generation + download
├── static/
│   ├── css/
│   │   └── luxury.css      # Full luxury design system (861 lines)
│   ├── js/
│   │   └── app.js          # SPA behavior: modal, search, filter, swipe
│   └── brand/
│       └── logo.png        # Official brand logo (your file)
├── uploads/                # Customer image uploads (gitignored)
│   ├── items/
│   └── brand/
├── seed/
│   └── seed_data.py        # 18 luxury items + categories + reviews
├── run.py                  # Entry point
├── requirements.txt
├── .env.example
└── README.md
```

---

## Admin Panel Features

| Section | Features |
|---|---|
| **Dashboard** | Stats, top viewed, top rated, pending reviews, activity |
| **Items** | Add/edit/delete, images, pricing, offers, tags, frame style, SEO |
| **Categories** | CRUD, icons, Arabic/English, sort order, featured flag |
| **Reviews** | Approve/reject/pin/hide/spam, admin reply, filter by status |
| **Brand** | Name, logo, tagline, contact, social links, hero content |
| **QR Codes** | Generate gold-on-black QR, download PNG, per branch/table |

---

## Design System

| Token | Value |
|---|---|
| `--gold` | `#C9A84C` (from logo) |
| `--gold-light` | `#E8D08A` |
| `--black` | `#0a0a0a` |
| `--cream` | `#F0E6CC` |
| Display font | Cormorant Garamond 300/400/600 |
| Arabic font | Tajawal 300/400/700 |
| UI font | Montserrat 300/400 |

---

## Production Deployment

### PythonAnywhere (Free Tier)

```bash
# 1. Upload project files via Files tab
# 2. Open a Bash console:
pip install -r requirements.txt --user

# 3. Create a new Web App → Manual configuration → Python 3.11
# WSGI file: /var/www/yourusername_pythonanywhere_com_wsgi.py
```

```python
# WSGI file contents:
import sys
sys.path.insert(0, '/home/yourusername/alitaly')
from run import app as application
```

```bash
# 4. Set environment variables in Web tab → Environment variables:
SECRET_KEY=your-very-long-random-secret
FLASK_ENV=production

# 5. In console:
cd ~/alitaly
python seed/seed_data.py

# 6. Reload web app from PythonAnywhere dashboard
```

### VPS / Server (Gunicorn + Nginx)

```bash
gunicorn -w 4 -b 0.0.0.0:8000 "run:app"
```

```nginx
# Nginx config
server {
    listen 80;
    server_name yourdomain.com;

    location /static { alias /path/to/alitaly/static; }
    location /uploads { alias /path/to/alitaly/uploads; }

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

---

## Upgrading Database to PostgreSQL

```bash
pip install psycopg2-binary

# In .env:
DATABASE_URL=postgresql://user:password@localhost:5432/alitaly
```

No migration needed — SQLAlchemy recreates schema automatically.

---

## QR Code Setup

1. Deploy app to live domain
2. Go to **Admin → QR Codes**
3. Set Target URL to your live URL (e.g. `https://alitaly.pythonanywhere.com/`)
4. Set gold foreground `#C9A84C` + black background `#0a0a0a`
5. Click **Generate QR** → **Download PNG**
6. Print and place at tables

---

## Security Notes

- Change `SECRET_KEY` to a long random string before going live
- Change admin password from default `alitaly2024!` immediately
- Set `FLASK_ENV=production` on live server
- Use HTTPS in production (free via Let's Encrypt)
- Keep `uploads/` folder writable: `chmod 755 uploads`

---

*Al-Italy Patisserie — Where Artistry Meets Indulgence*
