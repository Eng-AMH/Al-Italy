from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, login_manager


# ─── Auth ──────────────────────────────────────────────────────────────────────

class Admin(UserMixin, db.Model):
    __tablename__ = 'admins'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    is_superadmin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


@login_manager.user_loader
def load_user(user_id):
    return Admin.query.get(int(user_id))


# ─── Category ──────────────────────────────────────────────────────────────────

class Category(db.Model):
    __tablename__ = 'categories'
    id = db.Column(db.Integer, primary_key=True)
    name_en = db.Column(db.String(120), nullable=False)
    name_ar = db.Column(db.String(120), nullable=False)
    slug = db.Column(db.String(120), unique=True, nullable=False)
    description_en = db.Column(db.Text)
    description_ar = db.Column(db.Text)
    icon = db.Column(db.String(10), default='✦')
    image_path = db.Column(db.String(255))
    sort_order = db.Column(db.Integer, default=0)
    is_featured = db.Column(db.Boolean, default=False)
    is_visible = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    items = db.relationship('Item', backref='category', lazy='dynamic')

    def item_count(self):
        return self.items.filter_by(is_visible=True).count()


# ─── Item ───────────────────────────────────────────────────────────────────────

class Item(db.Model):
    __tablename__ = 'items'
    id = db.Column(db.Integer, primary_key=True)
    name_en = db.Column(db.String(200), nullable=False)
    name_ar = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(200), unique=True, nullable=False)
    description_en = db.Column(db.Text)
    description_ar = db.Column(db.Text)
    tasting_notes = db.Column(db.Text)
    pairing_suggestion = db.Column(db.String(255))
    serving_info = db.Column(db.String(255))
    allergy_info = db.Column(db.String(255))

    # Pricing
    price = db.Column(db.Float, nullable=False, default=0)
    old_price = db.Column(db.Float)
    currency = db.Column(db.String(10), default='EGP')
    discount_label = db.Column(db.String(80), default='Special Offer')

    # Size / Weight
    weight = db.Column(db.String(80))
    size_options = db.Column(db.String(255))

    # Status flags
    is_visible = db.Column(db.Boolean, default=True)
    is_featured = db.Column(db.Boolean, default=False)
    is_new = db.Column(db.Boolean, default=False)
    is_offer = db.Column(db.Boolean, default=False)
    is_bestseller = db.Column(db.Boolean, default=False)

    # Occasion tags (comma-separated)
    occasion_tags = db.Column(db.String(255))
    collection_label = db.Column(db.String(120))

    # Visual
    cover_image = db.Column(db.String(255))
    frame_style = db.Column(db.String(80), default='thin-gold')

    # SEO
    seo_title = db.Column(db.String(255))
    seo_description = db.Column(db.Text)

    # Sorting
    sort_order = db.Column(db.Integer, default=0)
    homepage_priority = db.Column(db.Integer, default=0)
    view_count = db.Column(db.Integer, default=0)

    # Rating cache
    rating_avg = db.Column(db.Float, default=0)
    rating_count = db.Column(db.Integer, default=0)

    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    images = db.relationship('ItemImage', backref='item', lazy='dynamic',
                              cascade='all, delete-orphan')
    reviews = db.relationship('Review', backref='item', lazy='dynamic',
                               cascade='all, delete-orphan')

    def update_rating(self):
        approved = self.reviews.filter_by(status='approved').all()
        if approved:
            self.rating_avg = round(sum(r.rating for r in approved) / len(approved), 1)
            self.rating_count = len(approved)
        else:
            self.rating_avg = 0
            self.rating_count = 0

    def get_tags(self):
        tags = []
        if self.is_new:
            tags.append(('new', 'New'))
        if self.is_offer:
            tags.append(('offer', 'Offer'))
        if self.is_bestseller:
            tags.append(('bestseller', 'Bestseller'))
        if self.is_featured:
            tags.append(('featured', 'Featured'))
        return tags

    def get_occasion_tags(self):
        if self.occasion_tags:
            return [t.strip() for t in self.occasion_tags.split(',') if t.strip()]
        return []


class ItemImage(db.Model):
    __tablename__ = 'item_images'
    id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.Integer, db.ForeignKey('items.id'), nullable=False)
    path = db.Column(db.String(255), nullable=False)
    alt_text = db.Column(db.String(255))
    is_cover = db.Column(db.Boolean, default=False)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ─── Review ─────────────────────────────────────────────────────────────────────

class Review(db.Model):
    __tablename__ = 'reviews'
    id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.Integer, db.ForeignKey('items.id'), nullable=False)
    username = db.Column(db.String(80), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1–5
    comment = db.Column(db.Text)
    admin_reply = db.Column(db.Text)
    status = db.Column(db.String(20), default='pending')  # pending/approved/rejected/hidden
    is_pinned = db.Column(db.Boolean, default=False)
    is_spam = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ─── Brand Settings ──────────────────────────────────────────────────────────────

class BrandSetting(db.Model):
    __tablename__ = 'brand_settings'
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(120), unique=True, nullable=False)
    value = db.Column(db.Text)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    @classmethod
    def get(cls, key, default=''):
        setting = cls.query.filter_by(key=key).first()
        return setting.value if setting else default

    @classmethod
    def set(cls, key, value):
        setting = cls.query.filter_by(key=key).first()
        if setting:
            setting.value = value
        else:
            setting = cls(key=key, value=value)
            db.session.add(setting)
        db.session.commit()


# ─── QR Settings ────────────────────────────────────────────────────────────────

class QRCode(db.Model):
    __tablename__ = 'qr_codes'
    id = db.Column(db.Integer, primary_key=True)
    label = db.Column(db.String(120), nullable=False)
    target_url = db.Column(db.String(500), nullable=False)
    branch = db.Column(db.String(120))
    table_number = db.Column(db.String(20))
    fg_color = db.Column(db.String(10), default='#C9A84C')
    bg_color = db.Column(db.String(10), default='#0a0a0a')
    logo_embedded = db.Column(db.Boolean, default=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ─── Audit Log ──────────────────────────────────────────────────────────────────

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer, db.ForeignKey('admins.id'))
    action = db.Column(db.String(120), nullable=False)
    entity_type = db.Column(db.String(80))
    entity_id = db.Column(db.Integer)
    details = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
