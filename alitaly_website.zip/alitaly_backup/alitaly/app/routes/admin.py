import os, json
from flask import (Blueprint, render_template, request, redirect,
                   url_for, flash, jsonify, current_app, send_file)
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from slugify import slugify
from app.models import Admin, Item, ItemImage, Category, Review, BrandSetting, QRCode, AuditLog, db
from datetime import datetime
import qrcode
import io
import base64

admin_bp = Blueprint('admin', __name__)
ALLOWED_EXT = {'png', 'jpg', 'jpeg', 'webp', 'gif'}


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT


def log_action(action, entity_type=None, entity_id=None, details=None):
    log = AuditLog(admin_id=current_user.id, action=action,
                   entity_type=entity_type, entity_id=entity_id,
                   details=details)
    db.session.add(log)


def save_image(file, subfolder='items'):
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        ts = datetime.utcnow().strftime('%Y%m%d%H%M%S%f')
        filename = f"{ts}_{filename}"
        folder = os.path.join(current_app.config['UPLOAD_FOLDER'], subfolder)
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, filename)
        file.save(path)
        return f"uploads/{subfolder}/{filename}"
    return None


# ─── Auth ──────────────────────────────────────────────────────────────────────

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('admin.dashboard'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = Admin.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user, remember=True)
            return redirect(url_for('admin.dashboard'))
        flash('Invalid credentials', 'error')
    return render_template('admin/login.html')


@admin_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('admin.login'))


# ─── Dashboard ─────────────────────────────────────────────────────────────────

@admin_bp.route('/')
@login_required
def dashboard():
    stats = {
        'total_items': Item.query.count(),
        'visible_items': Item.query.filter_by(is_visible=True).count(),
        'total_categories': Category.query.count(),
        'new_items': Item.query.filter_by(is_new=True).count(),
        'featured_items': Item.query.filter_by(is_featured=True).count(),
        'offer_items': Item.query.filter_by(is_offer=True).count(),
        'bestseller_items': Item.query.filter_by(is_bestseller=True).count(),
        'pending_reviews': Review.query.filter_by(status='pending').count(),
        'approved_reviews': Review.query.filter_by(status='approved').count(),
    }
    recent_reviews = Review.query.order_by(Review.created_at.desc()).limit(5).all()
    top_viewed = Item.query.filter_by(is_visible=True)\
        .order_by(Item.view_count.desc()).limit(5).all()
    top_rated = Item.query.filter(Item.rating_avg > 0, Item.is_visible == True)\
        .order_by(Item.rating_avg.desc()).limit(5).all()
    recent_logs = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(10).all()
    return render_template('admin/dashboard.html',
                           stats=stats, recent_reviews=recent_reviews,
                           top_viewed=top_viewed, top_rated=top_rated,
                           recent_logs=recent_logs)


# ─── Items ─────────────────────────────────────────────────────────────────────

@admin_bp.route('/items')
@login_required
def items():
    q = request.args.get('q', '')
    cat_id = request.args.get('category', type=int)
    tag = request.args.get('tag', '')
    query = Item.query
    if q:
        query = query.filter(
            Item.name_en.ilike(f'%{q}%') | Item.name_ar.ilike(f'%{q}%'))
    if cat_id:
        query = query.filter_by(category_id=cat_id)
    if tag == 'new':
        query = query.filter_by(is_new=True)
    elif tag == 'featured':
        query = query.filter_by(is_featured=True)
    elif tag == 'offer':
        query = query.filter_by(is_offer=True)
    elif tag == 'bestseller':
        query = query.filter_by(is_bestseller=True)
    elif tag == 'hidden':
        query = query.filter_by(is_visible=False)
    items = query.order_by(Item.homepage_priority.desc(), Item.sort_order).all()
    categories = Category.query.order_by(Category.sort_order).all()
    return render_template('admin/items.html', items=items,
                           categories=categories, q=q,
                           active_cat=cat_id, active_tag=tag)


@admin_bp.route('/items/new', methods=['GET', 'POST'])
@login_required
def item_new():
    categories = Category.query.order_by(Category.sort_order).all()
    if request.method == 'POST':
        item = Item()
        _apply_item_form(item, request)
        db.session.add(item)
        db.session.flush()
        _handle_images(item, request)
        log_action('create_item', 'item', item.id, item.name_en)
        db.session.commit()
        flash('Item created successfully', 'success')
        return redirect(url_for('admin.items'))
    return render_template('admin/item_form.html', item=None, categories=categories,
                           frame_styles=_frame_styles(), action='new')


@admin_bp.route('/items/<int:item_id>/edit', methods=['GET', 'POST'])
@login_required
def item_edit(item_id):
    item = Item.query.get_or_404(item_id)
    categories = Category.query.order_by(Category.sort_order).all()
    if request.method == 'POST':
        _apply_item_form(item, request)
        _handle_images(item, request)
        log_action('edit_item', 'item', item.id, item.name_en)
        db.session.commit()
        flash('Item updated', 'success')
        return redirect(url_for('admin.items'))
    images = item.images.order_by(ItemImage.sort_order).all()
    return render_template('admin/item_form.html', item=item,
                           categories=categories, images=images,
                           frame_styles=_frame_styles(), action='edit')


@admin_bp.route('/items/<int:item_id>/delete', methods=['POST'])
@login_required
def item_delete(item_id):
    item = Item.query.get_or_404(item_id)
    log_action('delete_item', 'item', item_id, item.name_en)
    db.session.delete(item)
    db.session.commit()
    flash('Item deleted', 'success')
    return redirect(url_for('admin.items'))


@admin_bp.route('/items/<int:item_id>/toggle/<field>', methods=['POST'])
@login_required
def item_toggle(item_id, field):
    item = Item.query.get_or_404(item_id)
    valid_fields = ['is_visible', 'is_featured', 'is_new', 'is_offer', 'is_bestseller']
    if field in valid_fields:
        setattr(item, field, not getattr(item, field))
        db.session.commit()
        return jsonify({'status': 'ok', 'value': getattr(item, field)})
    return jsonify({'status': 'error'}), 400


@admin_bp.route('/images/<int:img_id>/delete', methods=['POST'])
@login_required
def image_delete(img_id):
    img = ItemImage.query.get_or_404(img_id)
    item = db.session.get(Item, img.item_id)  # FIX 3: use db.session.get instead of Query.get
    was_cover = img.is_cover
    db.session.delete(img)
    db.session.flush()
    # FIX 4: if deleted image was the cover, promote the next image or clear cover_image
    if was_cover and item:
        next_img = ItemImage.query.filter_by(item_id=item.id).order_by(ItemImage.sort_order).first()
        if next_img:
            next_img.is_cover = True
            item.cover_image = next_img.path
        else:
            item.cover_image = None
    db.session.commit()
    return jsonify({'status': 'ok'})


@admin_bp.route('/images/<int:img_id>/set-cover', methods=['POST'])
@login_required
def image_set_cover(img_id):
    img = ItemImage.query.get_or_404(img_id)
    ItemImage.query.filter_by(item_id=img.item_id).update({'is_cover': False})
    img.is_cover = True
    item = db.session.get(Item, img.item_id)  # FIX 3: use db.session.get instead of Query.get
    if item:
        item.cover_image = img.path
    db.session.commit()
    return jsonify({'status': 'ok'})


# ─── Categories ────────────────────────────────────────────────────────────────

@admin_bp.route('/categories')
@login_required
def categories():
    cats = Category.query.order_by(Category.sort_order).all()
    return render_template('admin/categories.html', categories=cats)


@admin_bp.route('/categories/new', methods=['GET', 'POST'])
@login_required
def category_new():
    if request.method == 'POST':
        # FIX 2: unique slug for categories
        base_slug = slugify(request.form['name_en'])
        candidate = base_slug
        counter = 2
        while Category.query.filter_by(slug=candidate).first():
            candidate = f"{base_slug}-{counter}"
            counter += 1

        cat = Category(
            name_en=request.form['name_en'],
            name_ar=request.form['name_ar'],
            slug=candidate,
            description_en=request.form.get('description_en', ''),
            description_ar=request.form.get('description_ar', ''),
            icon=request.form.get('icon', '✦'),
            sort_order=request.form.get('sort_order', 0, type=int),
            is_featured=bool(request.form.get('is_featured')),
            is_visible=bool(request.form.get('is_visible'))  # FIX 5: consistent with category_edit
        )
        if 'image' in request.files:
            path = save_image(request.files['image'], 'categories')
            if path:
                cat.image_path = path
        db.session.add(cat)
        db.session.commit()
        flash('Category created', 'success')
        return redirect(url_for('admin.categories'))
    return render_template('admin/category_form.html', cat=None, action='new')


@admin_bp.route('/categories/<int:cat_id>/edit', methods=['GET', 'POST'])
@login_required
def category_edit(cat_id):
    cat = Category.query.get_or_404(cat_id)
    if request.method == 'POST':
        cat.name_en = request.form['name_en']
        cat.name_ar = request.form['name_ar']
        cat.description_en = request.form.get('description_en', '')
        cat.description_ar = request.form.get('description_ar', '')
        cat.icon = request.form.get('icon', '✦')
        cat.sort_order = request.form.get('sort_order', 0, type=int)
        cat.is_featured = bool(request.form.get('is_featured'))
        cat.is_visible = bool(request.form.get('is_visible'))
        if 'image' in request.files and request.files['image'].filename:
            path = save_image(request.files['image'], 'categories')
            if path:
                cat.image_path = path
        db.session.commit()
        flash('Category updated', 'success')
        return redirect(url_for('admin.categories'))
    return render_template('admin/category_form.html', cat=cat, action='edit')


@admin_bp.route('/categories/<int:cat_id>/delete', methods=['POST'])
@login_required
def category_delete(cat_id):
    cat = Category.query.get_or_404(cat_id)
    db.session.delete(cat)
    db.session.commit()
    flash('Category deleted', 'success')
    return redirect(url_for('admin.categories'))


# ─── Reviews ───────────────────────────────────────────────────────────────────

@admin_bp.route('/reviews')
@login_required
def reviews():
    status = request.args.get('status', 'pending')
    query = Review.query
    if status != 'all':
        query = query.filter_by(status=status)
    reviews = query.order_by(Review.created_at.desc()).all()
    counts = {
        'pending': Review.query.filter_by(status='pending').count(),
        'approved': Review.query.filter_by(status='approved').count(),
        'rejected': Review.query.filter_by(status='rejected').count(),
        'hidden': Review.query.filter_by(status='hidden').count(),
    }
    return render_template('admin/reviews.html', reviews=reviews,
                           active_status=status, counts=counts)


@admin_bp.route('/reviews/<int:review_id>/<action>', methods=['POST'])
@login_required
def review_action(review_id, action):
    review = Review.query.get_or_404(review_id)
    if action == 'approve':
        review.status = 'approved'
    elif action == 'reject':
        review.status = 'rejected'
    elif action == 'hide':
        review.status = 'hidden'
    elif action == 'pin':
        review.is_pinned = True
    elif action == 'unpin':
        review.is_pinned = False
    elif action == 'spam':
        review.is_spam = True
        review.status = 'rejected'
    elif action == 'reply':
        review.admin_reply = request.form.get('reply', '')
    if action in ('approve', 'reject', 'hide'):
        item = db.session.get(Item, review.item_id)  # FIX 3: use db.session.get instead of Query.get
        if item:
            item.update_rating()
    db.session.commit()
    return jsonify({'status': 'ok'})


# ─── Brand Settings ────────────────────────────────────────────────────────────

@admin_bp.route('/brand', methods=['GET', 'POST'])
@login_required
def brand():
    if request.method == 'POST':
        fields = ['brand_name', 'brand_name_ar', 'tagline', 'tagline_ar',
                  'phone', 'whatsapp', 'location', 'instagram', 'facebook',
                  'tiktok', 'hero_title', 'hero_subtitle', 'footer_text']
        for field in fields:
            BrandSetting.set(field, request.form.get(field, ''))
        if 'logo' in request.files and request.files['logo'].filename:
            logo_file = request.files['logo']
            path = save_image(logo_file, 'brand')
            if path:
                BrandSetting.set('logo_path', path)
        flash('Brand settings updated', 'success')
        return redirect(url_for('admin.brand'))
    settings = {}
    for key in ['brand_name', 'brand_name_ar', 'tagline', 'tagline_ar',
                'phone', 'whatsapp', 'location', 'instagram', 'facebook',
                'tiktok', 'hero_title', 'hero_subtitle', 'footer_text', 'logo_path']:
        settings[key] = BrandSetting.get(key)
    return render_template('admin/brand.html', settings=settings)


# ─── QR Codes ──────────────────────────────────────────────────────────────────

@admin_bp.route('/qr')
@login_required
def qr_list():
    qr_codes = QRCode.query.order_by(QRCode.created_at.desc()).all()
    return render_template('admin/qr.html', qr_codes=qr_codes)


@admin_bp.route('/qr/new', methods=['POST'])
@login_required
def qr_new():
    qr = QRCode(
        label=request.form.get('label', 'Main Menu'),
        target_url=request.form.get('target_url', ''),
        branch=request.form.get('branch', ''),
        table_number=request.form.get('table_number', ''),
        fg_color=request.form.get('fg_color', '#C9A84C'),
        bg_color=request.form.get('bg_color', '#0a0a0a'),
        logo_embedded=bool(request.form.get('logo_embedded'))
    )
    db.session.add(qr)
    db.session.commit()
    flash('QR Code created', 'success')
    return redirect(url_for('admin.qr_list'))


@admin_bp.route('/qr/<int:qr_id>/generate')
@login_required
def qr_generate(qr_id):
    qr_obj = QRCode.query.get_or_404(qr_id)
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=10, border=4)
    qr.add_data(qr_obj.target_url)
    qr.make(fit=True)
    img = qr.make_image(fill_color=qr_obj.fg_color, back_color=qr_obj.bg_color)
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    b64 = base64.b64encode(buf.getvalue()).decode()
    return jsonify({'image': f'data:image/png;base64,{b64}', 'url': qr_obj.target_url})


@admin_bp.route('/qr/<int:qr_id>/delete', methods=['POST'])
@login_required
def qr_delete(qr_id):
    qr = QRCode.query.get_or_404(qr_id)
    db.session.delete(qr)
    db.session.commit()
    flash('QR Code deleted', 'success')
    return redirect(url_for('admin.qr_list'))


# ─── Helpers ───────────────────────────────────────────────────────────────────

def _frame_styles():
    return [
        ('none', 'No Frame'),
        ('thin-gold', 'Thin Gold'),
        ('double-line', 'Double Line Luxury'),
        ('shadow', 'Soft Shadow'),
        ('ornate', 'Ornate Premium'),
        ('rounded', 'Rounded Premium'),
        ('glow', 'Subtle Glow'),
        ('offer-frame', 'Offer Special'),
        ('bestseller-frame', 'Bestseller Special'),
    ]


def _apply_item_form(item, req):
    item.name_en = req.form.get('name_en', '').strip()
    item.name_ar = req.form.get('name_ar', '').strip()
    raw_slug = req.form.get('slug', '').strip() or item.name_en
    base_slug = slugify(raw_slug)

    # FIX 1: handle slug uniqueness correctly for both new and existing items
    if item.id:
        # editing existing item — exclude self from uniqueness check
        existing = Item.query.filter(Item.slug == base_slug, Item.id != item.id).first()
        item.slug = f"{base_slug}-{item.id}" if existing else base_slug
    else:
        # new item — item.id is None, use counter to find unique slug
        candidate = base_slug
        counter = 2
        while Item.query.filter_by(slug=candidate).first():
            candidate = f"{base_slug}-{counter}"
            counter += 1
        item.slug = candidate

    item.description_en = req.form.get('description_en', '')
    item.description_ar = req.form.get('description_ar', '')
    item.tasting_notes = req.form.get('tasting_notes', '')
    item.pairing_suggestion = req.form.get('pairing_suggestion', '')
    item.serving_info = req.form.get('serving_info', '')
    item.allergy_info = req.form.get('allergy_info', '')
    item.price = req.form.get('price', 0, type=float)
    old_price = req.form.get('old_price', '', type=str).strip()
    item.old_price = float(old_price) if old_price else None
    item.discount_label = req.form.get('discount_label', 'Special Offer')
    item.currency = req.form.get('currency', 'EGP')
    item.weight = req.form.get('weight', '')
    item.size_options = req.form.get('size_options', '')
    item.occasion_tags = req.form.get('occasion_tags', '')
    item.collection_label = req.form.get('collection_label', '')
    item.frame_style = req.form.get('frame_style', 'thin-gold')
    item.category_id = req.form.get('category_id', type=int)
    item.sort_order = req.form.get('sort_order', 0, type=int)
    item.homepage_priority = req.form.get('homepage_priority', 0, type=int)
    item.seo_title = req.form.get('seo_title', '')
    item.seo_description = req.form.get('seo_description', '')
    item.is_visible = bool(req.form.get('is_visible'))
    item.is_featured = bool(req.form.get('is_featured'))
    item.is_new = bool(req.form.get('is_new'))
    item.is_offer = bool(req.form.get('is_offer'))
    item.is_bestseller = bool(req.form.get('is_bestseller'))
    item.updated_at = datetime.utcnow()


def _handle_images(item, req):
    files = req.files.getlist('images')
    for f in files:
        if f and allowed_file(f.filename):
            path = save_image(f, 'items')
            if path:
                img = ItemImage(item_id=item.id, path=path)
                db.session.add(img)
                if not item.cover_image:
                    item.cover_image = path
                    img.is_cover = True