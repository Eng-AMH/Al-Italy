from flask import Blueprint, jsonify, request
from app.models import Item, Category, Review, db

api_bp = Blueprint('api', __name__)


@api_bp.route('/items')
def items():
    q = request.args.get('q', '')
    cat = request.args.get('category', '')
    tag = request.args.get('tag', '')
    query = Item.query.filter_by(is_visible=True)
    if q:
        query = query.filter(
            Item.name_en.ilike(f'%{q}%') | Item.name_ar.ilike(f'%{q}%'))
    if cat:
        from app.models import Category as Cat
        c = Cat.query.filter_by(slug=cat).first()
        if c:
            query = query.filter_by(category_id=c.id)
    if tag == 'new':
        query = query.filter_by(is_new=True)
    elif tag == 'offer':
        query = query.filter_by(is_offer=True)
    elif tag == 'featured':
        query = query.filter_by(is_featured=True)
    elif tag == 'bestseller':
        query = query.filter_by(is_bestseller=True)
    items = query.order_by(
        Item.is_featured.desc(), Item.homepage_priority.desc()).all()
    return jsonify([{
        'id': i.id, 'name_en': i.name_en, 'name_ar': i.name_ar,
        'slug': i.slug, 'price': i.price, 'old_price': i.old_price,
        'currency': i.currency, 'cover_image': i.cover_image,
        'is_new': i.is_new, 'is_offer': i.is_offer,
        'is_bestseller': i.is_bestseller, 'is_featured': i.is_featured,
        'rating_avg': i.rating_avg, 'rating_count': i.rating_count,
        'frame_style': i.frame_style, 'category_id': i.category_id
    } for i in items])


@api_bp.route('/categories')
def categories():
    cats = Category.query.filter_by(is_visible=True).order_by(Category.sort_order).all()
    return jsonify([{
        'id': c.id, 'name_en': c.name_en, 'name_ar': c.name_ar,
        'slug': c.slug, 'icon': c.icon, 'item_count': c.item_count()
    } for c in cats])


@api_bp.route('/item/<slug>/reviews')
def item_reviews(slug):
    item = Item.query.filter_by(slug=slug).first_or_404()
    reviews = Review.query.filter_by(
        item_id=item.id, status='approved'
    ).order_by(Review.is_pinned.desc(), Review.created_at.desc()).all()
    return jsonify([{
        'id': r.id, 'username': r.username, 'rating': r.rating,
        'comment': r.comment, 'is_pinned': r.is_pinned,
        'admin_reply': r.admin_reply,
        'created_at': r.created_at.strftime('%b %Y')
    } for r in reviews])


@api_bp.route('/search')
def search():
    q = request.args.get('q', '').strip()
    if not q or len(q) < 2:
        return jsonify([])
    items = Item.query.filter(
        Item.is_visible == True,
        (Item.name_en.ilike(f'%{q}%') | Item.name_ar.ilike(f'%{q}%'))
    ).limit(8).all()
    return jsonify([{
        'name_en': i.name_en, 'name_ar': i.name_ar,
        'slug': i.slug, 'price': i.price,
        'currency': i.currency, 'cover_image': i.cover_image
    } for i in items])
