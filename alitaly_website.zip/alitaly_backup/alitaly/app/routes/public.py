import json
from flask import Blueprint, render_template, request, jsonify, abort
from app.models import Item, ItemImage, Category, Review, BrandSetting, db
from datetime import datetime

public_bp = Blueprint('public', __name__)


def get_brand():
    keys = ['brand_name','brand_name_ar','tagline','tagline_ar','phone',
            'whatsapp','location','logo_path','hero_title','hero_subtitle',
            'footer_text','instagram','facebook','tiktok']
    brand = {k: BrandSetting.get(k) for k in keys}
    brand.setdefault('brand_name',   brand['brand_name']   or 'Al-Italy Patisserie')
    brand.setdefault('brand_name_ar',brand['brand_name_ar'] or 'الإيطالي')
    brand.setdefault('tagline',      brand['tagline']      or 'Where Artistry Meets Indulgence')
    brand.setdefault('tagline_ar',   brand['tagline_ar']   or 'حيث يلتقي الفن بالمتعة')
    return brand


def item_to_dict(item):
    return {
        'id': item.id, 'name_en': item.name_en, 'name_ar': item.name_ar,
        'slug': item.slug,
        'description_en': item.description_en or '',
        'description_ar': item.description_ar or '',
        'tasting_notes': item.tasting_notes or '',
        'pairing_suggestion': item.pairing_suggestion or '',
        'serving_info': item.serving_info or '',
        'allergy_info': item.allergy_info or '',
        'price': item.price, 'old_price': item.old_price,
        'currency': item.currency or 'EGP',
        'discount_label': item.discount_label or 'Special Offer',
        'cover_image': item.cover_image or '',
        'weight': item.weight or '',
        'is_new': item.is_new, 'is_offer': item.is_offer,
        'is_bestseller': item.is_bestseller, 'is_featured': item.is_featured,
        'rating_avg': item.rating_avg or 0, 'rating_count': item.rating_count or 0,
        'frame_style': item.frame_style or 'thin-gold',
        'category_id': item.category_id,
        'occasion_tags': item.get_occasion_tags(),
        'collection_label': item.collection_label or '',
    }


@public_bp.route('/')
def index():
    brand   = get_brand()
    featured    = Item.query.filter_by(is_featured=True, is_visible=True)\
                    .order_by(Item.homepage_priority.desc()).limit(6).all()
    new_items   = Item.query.filter_by(is_new=True, is_visible=True)\
                    .order_by(Item.created_at.desc()).limit(8).all()
    offers      = Item.query.filter_by(is_offer=True, is_visible=True)\
                    .order_by(Item.homepage_priority.desc()).limit(4).all()
    bestsellers = Item.query.filter_by(is_bestseller=True, is_visible=True)\
                    .order_by(Item.rating_avg.desc()).limit(8).all()
    all_items   = Item.query.filter_by(is_visible=True)\
                    .order_by(Item.is_featured.desc(),
                              Item.homepage_priority.desc(),
                              Item.sort_order.asc()).all()
    categories  = Category.query.filter_by(is_visible=True)\
                    .order_by(Category.sort_order).all()

    all_items_json  = json.dumps([item_to_dict(i) for i in all_items])
    categories_json = json.dumps([{
        'id': c.id, 'name_en': c.name_en, 'name_ar': c.name_ar,
        'slug': c.slug, 'icon': c.icon
    } for c in categories])

    return render_template('public/index.html',
                           brand=brand,
                           featured=featured, new_items=new_items,
                           offers=offers, bestsellers=bestsellers,
                           categories=categories,
                           all_items_json=all_items_json,
                           categories_json=categories_json)


@public_bp.route('/api/item/<slug>')
def item_api(slug):
    item = Item.query.filter_by(slug=slug, is_visible=True).first_or_404()
    item.view_count = (item.view_count or 0) + 1
    db.session.commit()

    images = [{'path': img.path, 'is_cover': img.is_cover, 'sort_order': img.sort_order}
              for img in item.images.order_by(ItemImage.sort_order).all()]
    if not images and item.cover_image:
        images = [{'path': item.cover_image, 'is_cover': True, 'sort_order': 0}]

    reviews = [{
        'username': r.username, 'rating': r.rating,
        'comment': r.comment, 'is_pinned': r.is_pinned,
        'admin_reply': r.admin_reply,
        'date': r.created_at.strftime('%b %Y')
    } for r in Review.query.filter_by(item_id=item.id, status='approved')
               .order_by(Review.is_pinned.desc(), Review.created_at.desc()).all()]

    related = [{
        'slug': i.slug, 'name_en': i.name_en, 'name_ar': i.name_ar,
        'price': i.price, 'currency': i.currency or 'EGP',
        'cover_image': i.cover_image or ''
    } for i in Item.query.filter(
        Item.category_id == item.category_id,
        Item.id != item.id, Item.is_visible == True
    ).limit(4).all()]

    return jsonify({**item_to_dict(item), 'images': images,
                    'reviews': reviews, 'related': related,
                    'category_name': item.category.name_en if item.category else ''})


@public_bp.route('/review/submit/<int:item_id>', methods=['POST'])
def submit_review(item_id):
    item = Item.query.get_or_404(item_id)
    username = request.form.get('username', '').strip()
    rating   = request.form.get('rating', type=int)
    comment  = request.form.get('comment', '').strip()

    if not username or not rating or not 1 <= rating <= 5:
        return jsonify({'status': 'error', 'message': 'Please complete all fields'}), 400
    if len(username) > 60 or len(comment) > 600:
        return jsonify({'status': 'error', 'message': 'Content too long'}), 400

    review = Review(item_id=item_id, username=username,
                    rating=rating, comment=comment[:500], status='pending')
    db.session.add(review)
    db.session.commit()
    return jsonify({'status': 'success', 'message': 'Thank you! Your review is awaiting approval.'})
