import os
from app import create_app, db
from app.models import Admin, Category, Item, Review, BrandSetting, QRCode, AuditLog, ItemImage

app = create_app(os.environ.get('FLASK_ENV', 'development'))

@app.shell_context_processor
def make_shell_context():
    return dict(db=db, Admin=Admin, Category=Category,
                Item=Item, Review=Review, BrandSetting=BrandSetting)

@app.cli.command('init-db')
def init_db():
    """Create all database tables."""
    with db.engine.connect() as conn:
        db.metadata.create_all(conn, checkfirst=True)
        conn.commit()
    print('✦ Database tables created.')

@app.cli.command('create-admin')
def create_admin():
    import click
    username = click.prompt('Username')
    email    = click.prompt('Email')
    password = click.prompt('Password', hide_input=True, confirmation_prompt=True)
    a = Admin(username=username, email=email, is_superadmin=True)
    a.set_password(password)
    db.session.add(a)
    db.session.commit()
    print(f'✦ Admin "{username}" created.')

if __name__ == '__main__':
    with app.app_context():
        # Safe create — won't fail if tables already exist
        with db.engine.connect() as conn:
            db.metadata.create_all(conn, checkfirst=True)
            conn.commit()
    app.run(debug=True, host='0.0.0.0', port=5000)
