"""
Al-Italy Patisserie — Luxury Seed Data
Run AFTER starting the app:
  python run.py          # in one terminal
  python seed/seed_data.py   # in another terminal
OR run standalone (no server needed):
  python seed/seed_data.py
"""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app, db
from app.models import Admin, Category, Item, Review, BrandSetting, QRCode
from slugify import slugify

app = create_app('development')

CATEGORIES = [
    {'name_en':'Signature Cakes',   'name_ar':'كيك سيجنتشر',    'icon':'🎂','sort_order':1},
    {'name_en':'French Pastries',   'name_ar':'معجنات فرنسية',   'icon':'🥐','sort_order':2},
    {'name_en':'Mousse & Verrine',  'name_ar':'موس وفيرين',      'icon':'🍮','sort_order':3},
    {'name_en':'Cheesecake',        'name_ar':'تشيز كيك',        'icon':'🍰','sort_order':4},
    {'name_en':'Chocolate Atelier', 'name_ar':'أتيليه الشوكولا', 'icon':'🍫','sort_order':5},
    {'name_en':'Tarts & Tartlets',  'name_ar':'تارت وتارتليت',  'icon':'✦', 'sort_order':6},
    {'name_en':'Luxury Gift Boxes', 'name_ar':'صناديق الهدايا',  'icon':'🎁','sort_order':7},
    {'name_en':'Seasonal Specials', 'name_ar':'إصدارات موسمية',  'icon':'❖', 'sort_order':8},
]

ITEMS = [
  # ── Signature Cakes ──
  {
    'name_en':'Mille-Feuille Royale','name_ar':'ميل فوي رويال',
    'cat':0,'price':380,'old_price':None,
    'desc_en':'Eighteen whisper-thin layers of caramelised puff pastry, each embraced by our house vanilla diplomat cream. A crown jewel of French pâtisserie, elevated with edible gold leaf.',
    'desc_ar':'ثمانية عشر طبقة رفيعة من العجين المورق المكرمل مع كريمة دبلوماسية بالفانيليا. تحفة من الباتيسيري الفرنسية مزينة بورق الذهب الصالح للأكل.',
    'tasting':'Notes of caramelised butter, Madagascar vanilla, and a whisper of fleur de sel.',
    'pairing':'Moroccan mint tea or light roast espresso',
    'serving':'Serves 6–8','weight':'900g',
    'is_featured':True,'is_bestseller':True,'is_new':False,'is_offer':False,
    'frame':'glow','priority':10,'rating':4.9,'reviews':3,
    'occasions':'Birthday,Anniversary,Luxury Gift','collection':'Signature Classics',
  },
  {
    'name_en':'Opéra Noir','name_ar':'أوبيرا نوار',
    'cat':0,'price':340,'old_price':None,
    'desc_en':'Our interpretation of the iconic Parisian Opéra cake — six precise layers of almond joconde, espresso syrup, and Guanaja 70% chocolate ganache. Dark, intense, unforgettable.',
    'desc_ar':'تفسيرنا لكعكة الأوبيرا الباريسية الشهيرة — ست طبقات دقيقة من الجاتو اللوز مع شراب إسبريسو وغاناش شوكولاتة 70%.',
    'tasting':'Deep espresso, bitter dark chocolate, almond, and a lingering vanilla finish.',
    'pairing':'Double espresso or Arabica black coffee',
    'serving':'Serves 6','weight':'800g',
    'is_featured':True,'is_bestseller':True,'is_new':False,'is_offer':False,
    'frame':'bestseller-frame','priority':9,'rating':4.8,'reviews':5,
    'occasions':'Anniversary,Birthday','collection':'Signature Classics',
  },
  {
    'name_en':'Rose & Lychee Entremet','name_ar':'أونتريمه الورد والليتشي',
    'cat':0,'price':420,'old_price':None,
    'desc_en':'A poetic composition of rose-infused mousse, lychee jelly, and a base of crispy dacquoise. Veiled in a pale pink mirror glaze and crowned with crystallised rose petals.',
    'desc_ar':'تركيبة شاعرية من موس الورد ومربى الليتشي وقاعدة داكواز هشة. مغطاة بطلاء مرآة وردي وزهور ورد مبلورة.',
    'tasting':'Delicate rose water, tropical lychee, with a light floral finish.',
    'pairing':'Jasmine tea or champagne',
    'serving':'Serves 8','weight':'1kg',
    'is_featured':True,'is_bestseller':False,'is_new':True,'is_offer':False,
    'frame':'glow','priority':8,'rating':4.7,'reviews':2,
    'occasions':'Anniversary,Eid,Luxury Gift','collection':'Floral Collection',
  },
  {
    'name_en':'Caramel Beurre Salé','name_ar':'كيك الكراميل بالبطر المملح',
    'cat':0,'price':295,'old_price':None,
    'desc_en':'Three tiers of moist brown butter sponge layered with salted caramel cream and crunchy feuilletine. Draped in a glossy caramel mirror glaze.',
    'desc_ar':'ثلاث طبقات من الإسفنج بالبطر البني مع كريمة الكراميل المملح وفوييتين هش.',
    'tasting':'Warm caramel, sea salt, toasted butter, feuilletine crunch.',
    'pairing':'Caramel latte or chai',
    'serving':'Serves 8–10','weight':'1.1kg',
    'is_featured':False,'is_bestseller':True,'is_new':False,'is_offer':False,
    'frame':'thin-gold','priority':6,'rating':4.6,'reviews':4,
    'occasions':'Birthday,Gift','collection':'',
  },
  # ── French Pastries ──
  {
    'name_en':'Croissant au Beurre','name_ar':'كروسان بالبطر الفرنسي',
    'cat':1,'price':55,'old_price':None,
    'desc_en':'Laminated with AOP Charentes-Poitou butter through 27 precise folds. Audibly crisp on the outside, honeycomb-tender within.',
    'desc_ar':'مصنوع بطريقة التورتيج بزبدة AOP الفرنسية عبر 27 طية دقيقة. مقرمش من الخارج وطري كالقرص من الداخل.',
    'tasting':'Rich butter, subtle yeast, golden caramel notes.',
    'pairing':'Café au lait or fresh orange juice',
    'serving':'1 piece','weight':'85g',
    'is_featured':False,'is_bestseller':True,'is_new':False,'is_offer':False,
    'frame':'thin-gold','priority':5,'rating':4.9,'reviews':8,
    'occasions':'','collection':'Viennoiserie',
  },
  {
    'name_en':'Paris-Brest Praline','name_ar':'باريس برست بالبرالينيه',
    'cat':1,'price':140,'old_price':180,
    'desc_en':'The legendary wheel-shaped choux, filled with intensely nutty hazelnut praline mousseline. Dusted with feuilletine and pearl sugar.',
    'desc_ar':'شو بشكل دائرة أسطوري مملوء بكريمة موسلين البرالينيه بندق.',
    'tasting':'Toasted hazelnut, praline richness, light choux, pearl sugar crunch.',
    'pairing':'Hazelnut coffee or warm milk',
    'serving':'Serves 2','weight':'200g',
    'is_featured':False,'is_bestseller':False,'is_new':False,'is_offer':True,
    'discount_label':"Chef's Special",
    'frame':'offer-frame','priority':7,'rating':4.8,'reviews':3,
    'occasions':'Birthday,Eid','collection':'',
  },
  {
    'name_en':'Saint-Honoré','name_ar':'سان أونوريه',
    'cat':1,'price':160,'old_price':None,
    'desc_en':'Puff pastry base, caramel-dipped choux puffs, and a quenelle of house Chiboust cream.',
    'desc_ar':'قاعدة عجين مورق، كرات شو بالكراميل، وكريمة شيبوست.',
    'tasting':'Caramel, vanilla Chiboust, butter, sweet crunch.',
    'pairing':'Earl Grey or light roast coffee',
    'serving':'1 piece','weight':'180g',
    'is_featured':True,'is_bestseller':False,'is_new':True,'is_offer':False,
    'frame':'glow','priority':7,'rating':4.7,'reviews':2,
    'occasions':'Anniversary','collection':'French Classics',
  },
  # ── Mousse & Verrine ──
  {
    'name_en':'Valrhona Chocolate Mousse','name_ar':'موس شوكولاتة فالرونا',
    'cat':2,'price':95,'old_price':None,
    'desc_en':'Airy mousse crafted from Valrhona Guanaja 70% cacao, served in a crystal verrine over a thin praline crisp with cacao nibs and edible gold.',
    'desc_ar':'موس هوائي من شوكولاتة فالرونا 70% كاكاو. يُقدم في كأس كريستال فوق طبقة هشة.',
    'tasting':'Intense dark chocolate, subtle bitterness, smooth mousse texture.',
    'pairing':'Espresso or cognac',
    'serving':'1 verrine','weight':'130g',
    'is_featured':False,'is_bestseller':True,'is_new':False,'is_offer':False,
    'frame':'thin-gold','priority':4,'rating':4.8,'reviews':6,
    'occasions':'','collection':'',
  },
  {
    'name_en':'Passion Fruit & Mango Verrine','name_ar':'فيرين الرشاد والمانجو',
    'cat':2,'price':85,'old_price':115,
    'desc_en':'Layers of tropical passion fruit cremeux, mango compote, and coconut panna cotta.',
    'desc_ar':'طبقات من كريمة فاكهة العاطفة ومربى المانجو وبانا كوتا جوز الهند.',
    'tasting':'Tangy passion fruit, sweet mango, coconut cream.',
    'pairing':'Hibiscus tea or mango lassi',
    'serving':'1 verrine','weight':'120g',
    'is_featured':False,'is_bestseller':False,'is_new':True,'is_offer':True,
    'discount_label':'Limited Edition Price',
    'frame':'offer-frame','priority':6,'rating':4.5,'reviews':2,
    'occasions':'Eid,Gift','collection':'Tropical Collection',
  },
  # ── Cheesecake ──
  {
    'name_en':'New York Cheesecake','name_ar':'تشيز كيك نيويورك',
    'cat':3,'price':290,'old_price':None,
    'desc_en':'Classic New York–style baked cheesecake with graham cracker crust. Dense, creamy, served with our house berry compote.',
    'desc_ar':'تشيز كيك مخبوز بالطريقة النيويوركية الكلاسيكية مع قاعدة البسكويت.',
    'tasting':'Cream cheese richness, vanilla, slight tang, buttery crust.',
    'pairing':'Berry tea or cold brew coffee',
    'serving':'Serves 8','weight':'950g',
    'is_featured':False,'is_bestseller':True,'is_new':False,'is_offer':False,
    'frame':'thin-gold','priority':5,'rating':4.7,'reviews':5,
    'occasions':'Birthday','collection':'',
  },
  {
    'name_en':'Lotus Biscoff Cheesecake','name_ar':'تشيز كيك لوتس',
    'cat':3,'price':310,'old_price':380,
    'desc_en':'No-bake cheesecake on a Lotus Biscoff crust, filled with whipped Biscoff cream cheese, veiled in a warm Lotus glaze.',
    'desc_ar':'تشيز كيك بدون خبز على قاعدة لوتس بسكوف مع كريمة جبن لوتس وطلاء لوتس دافئ.',
    'tasting':'Caramelised biscuit, cream cheese, cinnamon, warm spice.',
    'pairing':'Cardamom coffee or hot chocolate',
    'serving':'Serves 8–10','weight':'1kg',
    'is_featured':True,'is_bestseller':True,'is_new':False,'is_offer':True,
    'discount_label':'Maison Offer',
    'frame':'bestseller-frame','priority':9,'rating':4.9,'reviews':9,
    'occasions':'Birthday,Eid,Gift','collection':'',
  },
  {
    'name_en':'Pistachio Rose Cheesecake','name_ar':'تشيز كيك الفستق والورد',
    'cat':3,'price':340,'old_price':None,
    'desc_en':'Baked cheesecake with a pistachio base and rose water–scented cream cheese filling. Crowned with crushed pistachios and dried rose petals.',
    'desc_ar':'تشيز كيك مخبوز بقاعدة فستق وحشوة جبن كريمي بماء الورد.',
    'tasting':'Floral rose, rich pistachio, cream cheese, light sweetness.',
    'pairing':'Oud rose tea or Arabic coffee',
    'serving':'Serves 8','weight':'900g',
    'is_featured':True,'is_bestseller':False,'is_new':True,'is_offer':False,
    'frame':'glow','priority':8,'rating':4.8,'reviews':3,
    'occasions':'Eid,Anniversary,Luxury Gift','collection':'Floral Collection',
  },
  # ── Chocolate Atelier ──
  {
    'name_en':'Dark Chocolate Fondant','name_ar':'فوندان الشوكولاتة الداكنة',
    'cat':4,'price':90,'old_price':None,
    'desc_en':'Warm Valrhona 72% dark chocolate fondant — a paper-thin shell giving way to a molten obsidian core. Served with Madagascar vanilla ice cream.',
    'desc_ar':'فوندان دافئ من شوكولاتة فالرونا 72% مع مركز منصهر. يُقدم مع آيس كريم فانيليا مدغشقر.',
    'tasting':'Intense dark chocolate, molten centre, vanilla contrast.',
    'pairing':'Espresso or aged rum',
    'serving':'1 piece + ice cream','weight':'120g',
    'is_featured':False,'is_bestseller':True,'is_new':False,'is_offer':False,
    'frame':'thin-gold','priority':4,'rating':4.9,'reviews':7,
    'occasions':'','collection':'',
  },
  {
    'name_en':'Rocher Prestige Box (12 pcs)','name_ar':'صندوق روشيه برستيج ١٢ قطعة',
    'cat':4,'price':240,'old_price':None,
    'desc_en':'Twelve hand-crafted chocolates — salted caramel ganache, hazelnut praline, raspberry coulis and Earl Grey infusion.',
    'desc_ar':'اثني عشر شوكولاتة يدوية — كراميل مملح وبرالينيه بندق وتوت العليق وإيرل جراي.',
    'tasting':'Varies by piece — see flavour card included.',
    'pairing':'Champagne or fine whisky',
    'serving':'12 pieces','weight':'360g',
    'is_featured':True,'is_bestseller':True,'is_new':False,'is_offer':False,
    'frame':'glow','priority':10,'rating':5.0,'reviews':4,
    'occasions':'Eid,Birthday,Anniversary,Luxury Gift,Limited Edition','collection':'Luxury Gift',
  },
  # ── Tarts ──
  {
    'name_en':'Tarte au Citron','name_ar':'تارت الليمون',
    'cat':5,'price':125,'old_price':None,
    'desc_en':'Sharp lemon curd tart in a shortcrust shell, finished with torched Italian meringue. Perfect balance of tart and sweet.',
    'desc_ar':'تارت كيرد الليمون الحاد في قالب عجينة قصيرة مع مرينغ إيطالي محروق.',
    'tasting':'Bright citrus, tangy lemon curd, light meringue sweetness.',
    'pairing':'Chamomile or green tea',
    'serving':'Serves 4','weight':'380g',
    'is_featured':False,'is_bestseller':False,'is_new':False,'is_offer':False,
    'frame':'thin-gold','priority':3,'rating':4.6,'reviews':3,
    'occasions':'','collection':'',
  },
  {
    'name_en':'Fraisier Tart','name_ar':'تارت الفريزييه',
    'cat':5,'price':145,'old_price':175,
    'desc_en':'Classic French fraisier as an individual tart — vanilla mousseline cream, fresh strawberries, pistachio frangipane base.',
    'desc_ar':'فريزييه فرنسي كلاسيكي كتارت فردي — كريمة موسلين فانيليا وفراولة طازجة وقاعدة فرانجيبان فستق.',
    'tasting':'Fresh strawberry, vanilla cream, pistachio, light almond.',
    'pairing':'Rosé wine or strawberry iced tea',
    'serving':'1 piece','weight':'160g',
    'is_featured':False,'is_bestseller':False,'is_new':True,'is_offer':True,
    'discount_label':"Today's Selection",
    'frame':'offer-frame','priority':5,'rating':4.7,'reviews':2,
    'occasions':'','collection':'',
  },
  # ── Luxury Gift Boxes ──
  {
    'name_en':'Al-Italy Luxury Assortment Box','name_ar':'صندوق الإيطالي الفاخر',
    'cat':6,'price':650,'old_price':None,
    'desc_en':'Six house pastries, four chocolate bonbons, and two personal cheesecakes — presented in our gold embossed signature box.',
    'desc_ar':'ست معجنات خاصة وأربع بونبون شوكولاتة وتشيزكيكتان فردية في صندوقنا الذهبي الأنيق.',
    'tasting':'A journey through our full collection.',
    'pairing':'Assorted teas included',
    'serving':'Serves 6–8','weight':'1.8kg',
    'is_featured':True,'is_bestseller':True,'is_new':False,'is_offer':False,
    'frame':'glow','priority':10,'rating':5.0,'reviews':6,
    'occasions':'Eid,Anniversary,Birthday,Luxury Gift,Limited Edition','collection':'Luxury Gift',
  },
  # ── Seasonal ──
  {
    'name_en':'Eid Mille-Feuille Box','name_ar':'صندوق ميل فوي العيد',
    'cat':7,'price':480,'old_price':600,
    'desc_en':'Limited-edition Eid creation — six individual mille-feuille adorned with pistachios, rose petals, and edible gold in a hand-stamped Eid gift box.',
    'desc_ar':'إصدار محدود للعيد — ست قطع ميل فوي فردية مزينة بالفستق وبتلات الورد والذهب في صندوق هدية العيد.',
    'tasting':'Rose, pistachio, vanilla, caramelised pastry.',
    'pairing':'Arabic coffee with cardamom',
    'serving':'6 pieces','weight':'1.2kg',
    'is_featured':True,'is_bestseller':False,'is_new':True,'is_offer':True,
    'discount_label':'Seasonal Special',
    'frame':'bestseller-frame','priority':10,'rating':4.9,'reviews':4,
    'occasions':'Eid,Luxury Gift,Limited Edition','collection':'Eid Edition',
  },
]

SAMPLE_REVIEWS = [
  {'username':'Nour A.',   'rating':5,'comment':'Every bite is an experience. The Mille-Feuille Royale is unlike anything I have had before. Pure luxury.'},
  {'username':'Ahmed K.',  'rating':5,'comment':'Ordered the gift box for our anniversary. The presentation alone left us speechless. Exceptional quality.'},
  {'username':'Layla M.',  'rating':5,'comment':'The Lotus Biscoff Cheesecake is absolutely divine. I keep coming back for it.'},
  {'username':'Omar S.',   'rating':4,'comment':'Outstanding flavours and beautiful presentation. The Opera Noir is my personal favourite.'},
  {'username':'Fatima H.', 'rating':5,'comment':'Best patisserie in Cairo. The rose and lychee entremet is a work of art.'},
]

BRAND_DEFAULTS = {
  'brand_name':    'Al-Italy Patisserie',
  'brand_name_ar': 'الإيطالي',
  'tagline':       'Where Artistry Meets Indulgence',
  'tagline_ar':    'حيث يلتقي الفن بالمتعة',
  'phone':         '+20 100 000 0000',
  'whatsapp':      '201000000000',
  'location':      'Cairo, Egypt',
  'instagram':     '', 'facebook': '', 'tiktok': '',
  'hero_title':    '', 'hero_subtitle': '',
  'footer_text':   '© Al-Italy Patisserie — Luxury Desserts',
}


def seed():
    with app.app_context():

        # ── Safe table creation (won't fail if tables exist) ──
        with db.engine.connect() as conn:
            db.metadata.create_all(conn, checkfirst=True)
            conn.commit()
        print('✦ Database ready')

        # ── Admin ──
        if not Admin.query.filter_by(username='admin').first():
            a = Admin(username='admin', email='admin@alitaly.com', is_superadmin=True)
            a.set_password('alitaly2024!')
            db.session.add(a)
            print('✦ Admin created  →  username: admin  /  password: alitaly2024!')
        else:
            print('  Admin already exists, skipping.')

        # ── Brand Settings ──
        for k, v in BRAND_DEFAULTS.items():
            if not BrandSetting.query.filter_by(key=k).first():
                BrandSetting.set(k, v)
        print('✦ Brand settings ready')

        # ── Categories ──
        cat_objs = []
        for c in CATEGORIES:
            sl = slugify(c['name_en'])
            existing = Category.query.filter_by(slug=sl).first()
            if existing:
                cat_objs.append(existing)
                continue
            cat = Category(
                name_en=c['name_en'], name_ar=c['name_ar'],
                slug=sl, icon=c['icon'],
                sort_order=c['sort_order'], is_visible=True,
            )
            db.session.add(cat)
            cat_objs.append(cat)
        db.session.flush()
        print(f'✦ {len(CATEGORIES)} categories ready')

        # ── Items ──
        created = 0
        for i_data in ITEMS:
            slug = slugify(i_data['name_en'])
            if Item.query.filter_by(slug=slug).first():
                continue
            cat = cat_objs[i_data['cat']]
            item = Item(
                name_en=i_data['name_en'], name_ar=i_data['name_ar'],
                slug=slug, category_id=cat.id,
                description_en=i_data['desc_en'],
                description_ar=i_data['desc_ar'],
                tasting_notes=i_data.get('tasting',''),
                pairing_suggestion=i_data.get('pairing',''),
                serving_info=i_data.get('serving',''),
                weight=i_data.get('weight',''),
                price=i_data['price'],
                old_price=i_data.get('old_price'),
                discount_label=i_data.get('discount_label','Special Offer'),
                is_featured=i_data['is_featured'],
                is_new=i_data['is_new'],
                is_offer=i_data['is_offer'],
                is_bestseller=i_data['is_bestseller'],
                is_visible=True,
                frame_style=i_data.get('frame','thin-gold'),
                homepage_priority=i_data.get('priority',0),
                sort_order=i_data.get('priority',0),
                occasion_tags=i_data.get('occasions',''),
                collection_label=i_data.get('collection',''),
                rating_avg=i_data.get('rating',0),
                rating_count=i_data.get('reviews',0),
            )
            db.session.add(item)
            created += 1
        db.session.flush()
        print(f'✦ {created} items created')

        # ── Reviews ──
        all_items = Item.query.all()
        rev_count = 0
        for idx, r_data in enumerate(SAMPLE_REVIEWS):
            if not all_items:
                break
            target = all_items[idx % len(all_items)]
            if Review.query.filter_by(item_id=target.id, username=r_data['username']).first():
                continue
            rev = Review(
                item_id=target.id,
                username=r_data['username'],
                rating=r_data['rating'],
                comment=r_data['comment'],
                status='approved',
                is_pinned=(idx == 0),
            )
            db.session.add(rev)
            rev_count += 1
        print(f'✦ {rev_count} reviews created')

        # ── QR Code ──
        if not QRCode.query.first():
            qr = QRCode(
                label='Main Menu', target_url='http://localhost:5000/',
                fg_color='#C9A84C', bg_color='#0a0a0a',
            )
            db.session.add(qr)
            print('✦ Default QR code created')

        db.session.commit()
        print('\n✦ Seeding complete!')
        print('  Menu  → http://localhost:5000/')
        print('  Admin → http://localhost:5000/admin')
        print('  Login → admin / alitaly2024!')


if __name__ == '__main__':
    seed()
