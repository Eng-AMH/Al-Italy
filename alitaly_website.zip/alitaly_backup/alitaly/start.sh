#!/bin/bash
# ═══════════════════════════════════════════════
#  Al-Italy Patisserie — Quick Start Script
# ═══════════════════════════════════════════════
set -e

echo ""
echo "✦ Al-Italy Patisserie — Starting..."
echo ""

# Kill any existing Flask process on port 5000
if lsof -Pi :5000 -sTCP:LISTEN -t >/dev/null 2>&1; then
  echo "  Stopping existing process on port 5000..."
  kill $(lsof -Pi :5000 -sTCP:LISTEN -t) 2>/dev/null || true
  sleep 1
fi

# Seed data
echo "  Seeding database..."
python seed/seed_data.py

echo ""
echo "  Starting server..."
echo "  Menu  → http://localhost:5000/"
echo "  Admin → http://localhost:5000/admin  (admin / alitaly2024!)"
echo ""
python run.py
