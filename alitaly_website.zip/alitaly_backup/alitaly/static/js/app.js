/* ═══════════════════════════════════════════════════════════════
   AL-ITALY PATISSERIE  ·  Luxury App — Single Page Experience
   Gold × Black × Cream  —  Mobile-First QR Catalog
═══════════════════════════════════════════════════════════════ */
'use strict';

// ── State ────────────────────────────────────────────────────
const S = {
  filter: 'all',
  item: null,
  galleryIdx: 0,
  galleryImages: [],
  reviewItemId: null,
  rating: 0,
  dragging: false,
  dragStartY: 0,
  dragCurrentY: 0,
};

// ── DOM refs ─────────────────────────────────────────────────
const $  = id => document.getElementById(id);
const stickyNav    = $('stickyNav');
const hero         = $('hero');
const modalBd      = $('modalBd');
const itemModal    = $('itemModal');
const modalScroll  = $('modalScroll');
const searchOverlay= $('searchOverlay');
const searchInput  = $('searchInput');
const searchResults= $('searchResults');
const catalogGrid  = $('catalogGrid');
const toast        = $('toast');
const revPanel     = $('revPanel');
const revPanelBd   = $('revPanelBd');
const revForm      = $('revForm');

// ── Sticky nav on scroll ─────────────────────────────────────
if (hero && stickyNav) {
  const obs = new IntersectionObserver(
    ([e]) => stickyNav.classList.toggle('visible', !e.isIntersecting),
    { threshold: 0 }
  );
  obs.observe(hero);
}

// ── Reveal on scroll ─────────────────────────────────────────
const revObs = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); revObs.unobserve(e.target); }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.reveal').forEach(el => revObs.observe(el));

// ── Hero CTA → scroll to catalog ─────────────────────────────
const heroCta = $('heroCta');
if (heroCta) {
  heroCta.addEventListener('click', () => {
    $('catalog-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
}

// ════════════════ CATALOG FILTER ════════════════

function setFilter(filter, btn) {
  S.filter = filter;

  // Sync both pill sets (sticky nav + catalog bar)
  document.querySelectorAll('[data-filter]').forEach(el => {
    el.classList.toggle('active', el.dataset.filter === filter);
  });

  // Scroll catalog into view only if user clicks nav (not filter bar)
  if (btn && btn.closest('.sticky-nav')) {
    $('catalog-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  renderCatalog();
}

function filterByCat(catId) {
  const target = $('catalog-section');
  if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  setTimeout(() => setFilter(`cat-${catId}`), 320);
}

function renderCatalog() {
  if (!catalogGrid) return;
  let items = [...ALL_ITEMS];
  const f = S.filter;

  if (f.startsWith('cat-')) {
    const id = parseInt(f.replace('cat-', ''));
    items = items.filter(i => i.category_id === id);
  } else if (f === 'featured')   items = items.filter(i => i.is_featured);
  else if (f === 'new')          items = items.filter(i => i.is_new);
  else if (f === 'offer')        items = items.filter(i => i.is_offer);
  else if (f === 'bestseller')   items = items.filter(i => i.is_bestseller);

  if (items.length === 0) {
    catalogGrid.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">✦</div>
        <p class="empty-t">No creations found</p>
        <p class="empty-s">Try a different selection</p>
      </div>`;
    return;
  }

  // Fade out → update → fade in
  catalogGrid.style.transition = 'opacity .22s ease,transform .22s ease';
  catalogGrid.style.opacity = '0';
  catalogGrid.style.transform = 'translateY(6px)';

  setTimeout(() => {
    catalogGrid.innerHTML = items.map(renderCard).join('');
    catalogGrid.style.opacity = '1';
    catalogGrid.style.transform = 'translateY(0)';
  }, 200);
}

function renderCard(item) {
  const img = item.cover_image
    ? `<img class="ic-img" src="/${item.cover_image}" alt="${esc(item.name_en)}" loading="lazy">`
    : `<div class="ic-img-empty">✦</div>`;

  const badges = [
    item.is_new        ? `<span class="badge b-new">New</span>`        : '',
    item.is_offer      ? `<span class="badge b-offer">Offer</span>`    : '',
    item.is_bestseller ? `<span class="badge b-best">Bestseller</span>`: '',
  ].filter(Boolean).join('');

  const price = item.old_price
    ? `<span class="p-current p-lg">${fmt(item.price)}</span>
       <span class="p-cur">${item.currency}</span>
       <span class="p-old">${fmt(item.old_price)}</span>`
    : `<span class="p-current p-lg">${fmt(item.price)}</span>
       <span class="p-cur">${item.currency}</span>`;

  const stars = item.rating_avg > 0
    ? `<div class="ic-stars">
         <span class="stars">${'★'.repeat(Math.round(item.rating_avg))}${'☆'.repeat(5 - Math.round(item.rating_avg))}</span>
         <span class="rating-ct">(${item.rating_count})</span>
       </div>` : '';

  return `
    <div class="item-card frame-${item.frame_style||'thin-gold'}" onclick="openItem('${item.slug}')">
      <div class="ic-img-wrap">
        ${img}
        ${badges ? `<div class="ic-badges">${badges}</div>` : ''}
      </div>
      <div class="ic-body">
        <div class="ic-name">${esc(item.name_en)}</div>
        <div class="ic-name-ar">${esc(item.name_ar)}</div>
        <div class="ic-price-row">${price}</div>
        ${stars}
      </div>
    </div>`;
}

// Initial render
renderCatalog();

// ════════════════ ITEM MODAL ════════════════

async function openItem(slug) {
  // Show skeleton immediately
  modalScroll.innerHTML = `
    <div class="modal-gallery shimmer" style="aspect-ratio:4/3"></div>
    <div class="modal-content">
      <div class="shimmer" style="height:28px;width:55%;margin-bottom:12px;border-radius:4px"></div>
      <div class="shimmer" style="height:18px;width:75%;margin-bottom:24px;border-radius:4px"></div>
      <div class="shimmer" style="height:48px;width:38%;border-radius:4px"></div>
    </div>`;
  openModal();

  try {
    const res = await fetch(`/api/item/${slug}`);
    if (!res.ok) throw new Error('not found');
    const item = await res.json();
    S.item = item;
    S.galleryIdx = 0;
    S.galleryImages = item.images?.length ? item.images
      : (item.cover_image ? [{ path: item.cover_image }] : []);
    renderModal(item);
    history.pushState({ slug }, '', `/item/${slug}`);
  } catch {
    modalScroll.innerHTML = `<div class="empty-state"><div class="empty-icon">✦</div><p class="empty-t">Creation not found</p></div>`;
  }
}

function openModal() {
  modalBd.classList.add('open');
  itemModal.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  modalBd.classList.remove('open');
  itemModal.classList.remove('open');
  document.body.style.overflow = '';
  history.pushState({}, '', '/');
  setTimeout(() => { S.item = null; modalScroll.innerHTML = ''; }, 500);
}

function renderModal(item) {
  const imgs = S.galleryImages;

  const gallery = imgs.length
    ? `<div class="modal-gallery" id="mGallery">
         <img class="gallery-img" id="mGImg" src="/${imgs[0].path}" alt="${esc(item.name_en)}">
         ${imgs.length > 1 ? `<div class="gallery-dots" id="mDots">
           ${imgs.map((_,i) => `<button class="g-dot${i===0?' active':''}" onclick="goGallery(${i})"></button>`).join('')}
         </div>` : ''}
       </div>`
    : `<div class="modal-gallery" style="display:flex;align-items:center;justify-content:center;background:var(--black-card)">
         <span style="color:var(--gold-border);font-size:3.5rem">✦</span>
       </div>`;

  const badges = [
    item.is_new        ? `<span class="badge b-new">New Arrival</span>`    : '',
    item.is_bestseller ? `<span class="badge b-best">Bestseller</span>`    : '',
    item.is_featured   ? `<span class="badge b-feat">House Selection</span>`: '',
  ].filter(Boolean).join('');

  const priceBlock = `
    <div class="modal-price-block">
      <span class="p-current p-xxl">${fmt(item.price)}</span>
      <span class="p-cur" style="font-size:.78rem;margin-left:5px">${item.currency}</span>
      ${item.old_price ? `<span class="p-old" style="font-size:.9rem;margin-left:8px">${fmt(item.old_price)} ${item.currency}</span>` : ''}
      ${item.is_offer && item.discount_label
        ? `<div class="modal-offer-tag">— ${esc(item.discount_label)} —</div>` : ''}
    </div>`;

  const meta = [
    item.weight          ? `<div class="meta-box"><span class="meta-lbl">Weight / Size</span><span class="meta-val">${esc(item.weight)}</span></div>`            : '',
    item.serving_info    ? `<div class="meta-box"><span class="meta-lbl">Serves</span><span class="meta-val">${esc(item.serving_info)}</span></div>`              : '',
    item.pairing_suggestion ? `<div class="meta-box"><span class="meta-lbl">Pairs With</span><span class="meta-val">${esc(item.pairing_suggestion)}</span></div>`: '',
    item.allergy_info    ? `<div class="meta-box"><span class="meta-lbl">Allergens</span><span class="meta-val">${esc(item.allergy_info)}</span></div>`           : '',
  ].filter(Boolean);

  const occTags = item.occasion_tags?.length
    ? `<div class="occ-tags">${item.occasion_tags.map(t => `<span class="occ-tag">${esc(t)}</span>`).join('')}</div>` : '';

  const ratingBlock = item.rating_avg > 0 ? `
    <div class="rating-summary">
      <div class="rating-big">${item.rating_avg}</div>
      <div>
        <div class="rev-stars rating-stars-row">${'★'.repeat(Math.round(item.rating_avg))}${'☆'.repeat(5-Math.round(item.rating_avg))}</div>
        <div class="rating-ct-text">From ${item.rating_count} review${item.rating_count !== 1?'s':''}</div>
      </div>
    </div>` : '';

  const reviews = item.reviews?.length
    ? item.reviews.map(r => `
        <div class="rev-card">
          <div class="rev-header">
            ${r.is_pinned ? '<span class="rev-pin">✦</span>' : ''}
            <span class="rev-user">${esc(r.username)}</span>
            ${r.date ? `<span class="rev-date">${r.date}</span>` : ''}
          </div>
          <div class="rev-stars">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</div>
          ${r.comment ? `<p class="rev-comment">"${esc(r.comment)}"</p>` : ''}
          ${r.admin_reply ? `
            <div class="rev-reply">
              <div class="rev-reply-lbl">Maison Response</div>
              <div class="rev-reply-text">${esc(r.admin_reply)}</div>
            </div>` : ''}
        </div>`).join('')
    : `<div style="padding:22px 0;text-align:center;font-family:var(--font-display);font-style:italic;font-size:.95rem;color:var(--cream-muted)">
         Be the first to share your experience
       </div>`;

  const related = item.related?.length ? `
    <div style="padding:22px 0 8px">
      <div class="ornament"><div class="ornament-diamond"></div></div>
    </div>
    <div class="modal-sub">You May Also Enjoy</div>
    <div class="related-row">
      ${item.related.map(r => `
        <div class="rel-card" onclick="closeModal();setTimeout(()=>openItem('${r.slug}'),380)">
          <div class="rel-img-wrap">
            ${r.cover_image
              ? `<img class="rel-img" src="/${r.cover_image}" alt="${esc(r.name_en)}" loading="lazy">`
              : `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:var(--black-card);color:var(--gold-border)">✦</div>`}
          </div>
          <div class="rel-name">${esc(r.name_en)}</div>
          <div class="rel-price">${fmt(r.price)} <small style="font-size:.6rem;font-weight:300;color:var(--cream-muted)">${r.currency}</small></div>
        </div>`).join('')}
    </div>` : '';

  modalScroll.innerHTML = `
    ${gallery}
    <div class="modal-content">
      ${badges ? `<div class="modal-badges">${badges}</div>` : ''}
      <h2 class="modal-name-en">${esc(item.name_en)}</h2>
      <p class="modal-name-ar">${esc(item.name_ar)}</p>
      <div class="modal-orn"><div class="ornament"><div class="ornament-diamond"></div></div></div>
      ${priceBlock}
      ${item.description_en ? `<p class="modal-desc">${esc(item.description_en)}</p>` : ''}
      ${item.description_ar ? `<p class="modal-desc-ar">${esc(item.description_ar)}</p>` : ''}
      ${item.tasting_notes ? `
        <div class="tasting-block">
          <span class="tasting-label">Tasting Notes</span>
          <p class="tasting-text">${esc(item.tasting_notes)}</p>
        </div>` : ''}
      ${meta.length ? `<div class="meta-grid">${meta.join('')}</div>` : ''}
      ${occTags}
      ${ratingBlock ? `<div style="padding:10px 0 4px"><div class="ornament"><div class="ornament-diamond"></div></div></div>${ratingBlock}` : ''}
      <div class="modal-sub">Guest Experiences</div>
      <div>${reviews}</div>
      <button class="write-review-btn" onclick="openRevPanel(${item.id})">
        <span>✦</span> Share Your Experience
      </button>
      ${related}
    </div>`;

  // Setup gallery touch swipe
  if (imgs.length > 1) setupGallerySwipe();
}

// ── Gallery ───────────────────────────────────────
function goGallery(idx) {
  S.galleryIdx = idx;
  const img = $('mGImg');
  if (!img || !S.galleryImages[idx]) return;
  img.style.opacity = '0';
  img.style.transform = 'scale(1.03)';
  img.style.transition = 'opacity .28s,transform .28s';
  setTimeout(() => {
    img.src = `/${S.galleryImages[idx].path}`;
    img.style.opacity = '1';
    img.style.transform = 'scale(1)';
  }, 150);
  document.querySelectorAll('.g-dot').forEach((d, i) => d.classList.toggle('active', i === idx));
}

function setupGallerySwipe() {
  const g = $('mGallery');
  if (!g) return;
  let sx = 0;
  g.addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true });
  g.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - sx;
    if (Math.abs(dx) > 48) {
      const total = S.galleryImages.length;
      const next = dx < 0
        ? (S.galleryIdx + 1) % total
        : (S.galleryIdx - 1 + total) % total;
      goGallery(next);
    }
  }, { passive: true });
}

// ── Drag to dismiss modal ────────────────────────
(function () {
  const handle = $('modalHandle');
  if (!handle || !itemModal) return;
  let sy = 0, cy = 0;

  const onStart = e => {
    sy = (e.touches?.[0] || e).clientY;
    S.dragging = true;
    itemModal.style.transition = 'none';
  };
  const onMove = e => {
    if (!S.dragging) return;
    cy = Math.max(0, (e.touches?.[0] || e).clientY - sy);
    itemModal.style.transform = `translateY(${cy}px)`;
  };
  const onEnd = () => {
    if (!S.dragging) return;
    S.dragging = false;
    itemModal.style.transition = '';
    cy > 130 ? closeModal() : (itemModal.style.transform = '');
    cy = 0;
  };

  handle.addEventListener('touchstart', onStart, { passive: true });
  document.addEventListener('touchmove', onMove, { passive: true });
  document.addEventListener('touchend', onEnd);
  // Desktop drag
  handle.addEventListener('mousedown', onStart);
  document.addEventListener('mousemove', e => { if (S.dragging) onMove(e); });
  document.addEventListener('mouseup', onEnd);
})();

// ════════════════ SEARCH ════════════════

function openSearch() {
  searchOverlay.classList.add('open');
  setTimeout(() => searchInput?.focus(), 100);
}
function closeSearch() {
  searchOverlay.classList.remove('open');
  if (searchInput)  searchInput.value = '';
  if (searchResults) searchResults.innerHTML = '';
}

let _sdebounce;
searchInput?.addEventListener('input', () => {
  clearTimeout(_sdebounce);
  _sdebounce = setTimeout(() => {
    const q = searchInput.value.toLowerCase().trim();
    if (q.length < 2) { searchResults.innerHTML = ''; return; }
    const res = ALL_ITEMS.filter(i =>
      i.name_en.toLowerCase().includes(q) || i.name_ar.includes(q)
    ).slice(0, 8);
    renderSearchResults(res, q);
  }, 180);
});
searchInput?.addEventListener('keydown', e => { if (e.key === 'Escape') closeSearch(); });

function renderSearchResults(items, q) {
  if (!searchResults) return;
  if (!items.length) {
    searchResults.innerHTML = `<div style="text-align:center;padding:32px 0;font-family:var(--font-display);font-style:italic;color:var(--cream-muted)">No creations found for "${esc(q)}"</div>`;
    return;
  }
  searchResults.innerHTML = items.map(i => `
    <div class="s-result" onclick="closeSearch();openItem('${i.slug}')">
      ${i.cover_image
        ? `<img class="s-thumb" src="/${i.cover_image}" alt="${esc(i.name_en)}" loading="lazy">`
        : `<div class="s-thumb-empty">✦</div>`}
      <div>
        <div class="s-name">${esc(i.name_en)}</div>
        <div class="s-name-ar">${esc(i.name_ar)}</div>
      </div>
      <div class="s-price">${fmt(i.price)} <small style="font-size:.65rem;color:var(--cream-muted)">${i.currency}</small></div>
    </div>`).join('');
}

// ════════════════ REVIEW PANEL ════════════════

function openRevPanel(itemId) {
  S.reviewItemId = itemId;
  S.rating = 0;
  revForm?.reset();
  updateStars(0);
  revPanelBd.classList.add('open');
  revPanel.classList.add('open');
}
function closeRevPanel() {
  revPanelBd.classList.remove('open');
  revPanel.classList.remove('open');
}

function updateStars(n) {
  document.querySelectorAll('.star-btn').forEach((b, i) => b.classList.toggle('active', i < n));
}

document.querySelectorAll('.star-btn').forEach((btn, i) => {
  btn.addEventListener('click', () => { S.rating = i + 1; updateStars(i + 1); });
  // Touch highlight
  btn.addEventListener('touchstart', () => updateStars(i + 1), { passive: true });
  btn.addEventListener('touchend', () => { S.rating = i + 1; }, { passive: true });
});

revForm?.addEventListener('submit', async e => {
  e.preventDefault();
  if (!S.rating) { showToast('Please select a star rating ✦'); return; }
  const fd = new FormData(revForm);
  fd.set('rating', S.rating);
  try {
    const res = await fetch(`/review/submit/${S.reviewItemId}`, { method: 'POST', body: fd });
    const data = await res.json();
    if (data.status === 'success') {
      showToast('Thank you for your experience ✦');
      closeRevPanel();
    } else {
      showToast(data.message || 'Could not submit review');
    }
  } catch {
    showToast('Something went wrong. Please try again.');
  }
});

// ════════════════ TOAST ════════════════

let _toastTimer;
function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => toast.classList.remove('show'), 3600);
}

// ════════════════ UTILITIES ════════════════

function fmt(n) { return n == null ? '' : Number(n).toFixed(0); }
function esc(s) {
  if (!s) return '';
  return String(s)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}

// ── Keyboard shortcuts ────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    if (searchOverlay.classList.contains('open'))  { closeSearch(); return; }
    if (revPanel.classList.contains('open'))       { closeRevPanel(); return; }
    if (itemModal.classList.contains('open'))      { closeModal(); }
  }
});

// ── Browser back restores catalog view ────────────
window.addEventListener('popstate', e => {
  if (!e.state?.slug && itemModal.classList.contains('open')) closeModal();
});

// ── Passive touch for scroll performance ──────────
document.addEventListener('touchstart', () => {}, { passive: true });
